#!/bin/bash

#ipaddress=$(cm vm list | grep satyam | awk '{print $11}'| head -1)
#sed -i "s/<remote-master-node>/$ipaddress/" inventory


touch benchmark_jetstream

starttime_deploy=$(date +%s)
ansible-playbook -i inventory playbook.yml --ask-sudo-pass -vvvv
endtime_deploy=$(date +%s)
totaltime_deploy=$((endtime_deploy-starttime_deploy))

echo $totaltime_deploy

echo "deployment file time $(($totaltime_deploy / 60)) minutes and $(($totaltime_deploy % 60)) seconds elapsed." >> benchmark_jetstream


sleep 10



ipaddress=$(cm vm list | grep tg841113 | awk '{print $11}'| head -1)

sed -i -e "s/<master-ip>/$ipaddress/g" inventory

starttime_transfer=$(date +%s)
ansible-playbook -i inventory tranfer-files-remotely.yml --ask-sudo-pass -vvvv
endtime_transfer=$(date +%s)
totaltime_transfer=$((endtime_transfer-starttime_transfer))

echo $totaltime_transfer

echo "transfer file time $(($totaltime_transfer / 60)) minutes and $(($totaltime_transfer % 60)) seconds elapsed." >> benchmark_jetstream





